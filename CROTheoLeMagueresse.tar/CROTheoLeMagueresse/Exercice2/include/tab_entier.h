#ifndef _tab_entier_h_
#define _tab_entier_h_


int *CreerTabEntier(int N);
void afficherTabEntier(int *tab, int N);
void remplirTabEntier(int *tab, int N);

#endif
