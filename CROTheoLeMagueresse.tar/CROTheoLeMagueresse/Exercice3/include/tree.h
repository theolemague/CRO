#ifndef _tree_h_
#define _tree_h_

TREE newTree(int value, TREE left_son, TREE right_son);
void printTree(TREE tree);

#endif
